<?php

$config['output_components_url']         = 'app/templates/out_components/';
$config['index_url']                     = 'app/templates/index/';
$config['pages_url']                     = 'app/templates/pages/';
$config['main_lang_dir']                 = '#$app_dir#lang/';
$config['components_dir']                = '#$app_dir#components/';
$config['templates_dir']                 = '#$app_dir#templates/';
$config['output_components_templates_dir'] = '#$templates_dir#out_components/';
$config['page_template_directory']       = '#$templates_dir#pages/';
$config['output_components_dir']         = '#$app_dir#components/output/';
$config['logic_components_dir']          = '#$app_dir#components/logic/';
$config['config_dir']                    = '#$framework_dir#config/';
$config['images_dir']                    = '#$templates_dir#images/';
