<?php

$config['logic_components']              = array (
  'auth' => 
  array (
  ),
  'news' => 
  array (
  ),
);
$config['output_components']             = array (
  'login' => 
  array (
    0 => 'auth',
  ),
  'latest_news_main' => 
  array (
    0 => 'news',
  ),
  'add_news' => 
  array (
    0 => 'news',
  ),
  'edit_delete_news' => 
  array (
    0 => 'news',
  ),
  'latest_news' => 
  array (
    0 => 'news',
  ),
  'menu' => 
  array (
  ),
);
$config['output_components_options']     = array (
  'latest_news_main' => 
  array (
    'css' => true,
    'js' => true,
  ),
  'add_news' => 
  array (
    'css' => true,
    'js' => true,
  ),
  'edit_delete_news' => 
  array (
    'css' => true,
    'js' => true,
  ),
  'latest_news' => 
  array (
    'css' => true,
    'js' => true,
  ),
  'menu' => 
  array (
    'css' => true,
    'js' => true,
  ),
);
$config['pages']                         = array (
  404 => 
  array (
  ),
  'maintenance' => 
  array (
  ),
  'error_page' => 
  array (
  ),
  'login' => 
  array (
  ),
  'main_page' => 
  array (
  ),
  'news_edit_page' => 
  array (
  ),
);
$config['pages_out_components']          = array (
  404 => 
  array (
  ),
  'maintenance' => 
  array (
  ),
  'error_page' => 
  array (
  ),
  'login' => 
  array (
    0 => 'login',
  ),
  'main_page' => 
  array (
    0 => 'latest_news_main',
  ),
  'news_edit_page' => 
  array (
    0 => 'add_news',
    1 => 'edit_delete_news',
  ),
);
$config['pages_templates']               = array (
);
$config['pages_access']                  = array (
  'news_edit_page' => 
  array (
    0 => 'authors',
  ),
);
$config['default_page']                  = '';
$config['empty_page_index']              = 'main_page';
$config['page_not_found_page']           = '404';
$config['page_maintenance']              = 'maintenance';
$config['error_page_url']                = 'error_page';
$config['wrap_components']               = true;
$config['common_output_components']      = array (
  'menu' => 
  array (
  ),
  'latest_news' => 
  array (
  ),
);
