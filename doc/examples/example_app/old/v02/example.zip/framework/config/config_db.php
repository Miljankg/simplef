<?php

$config['db_config']                     = array (
  'example' => 
  array (
    'db_type' => 'mysql',
    'db_user' => 'root',
    'db_pass' => 'superpassword2015',
    'db_host' => 'localhost',
    'db_name' => 'example',
  ),
);
