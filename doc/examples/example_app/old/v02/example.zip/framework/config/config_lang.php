<?php

$config['is_site_multilang']             = true;
$config['default_language']              = 'en';
$config['available_langs']               = array (
  0 => 'en',
);
$config['disabled_langs']                = array (
);
$config['lang_dir']                      = '#$app_dir#lang\\';
