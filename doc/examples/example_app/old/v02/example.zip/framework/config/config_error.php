<?php

$config['display_errors']                = 'on';
$config['error_reporting']               = 32767;
$config['debug_mode']                    = true;
$config['system_exception_type']         = 'Exception';
