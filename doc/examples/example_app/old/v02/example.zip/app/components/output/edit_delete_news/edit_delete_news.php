<?php

namespace Components\Output;

use Framework\Core\FrameworkClasses\Components\OutputComponent;

class EditDeleteNews extends OutputComponent
{
    protected function execute()
    {
    }
}