<?php

namespace Components\Output;

use Framework\Core\FrameworkClasses\Components\OutputComponent;

class LatestNews extends OutputComponent
{
    protected function execute()
    {
    }
}