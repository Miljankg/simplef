<?php

namespace Components\Logic;

use Framework\Core\FrameworkClasses\Components\LogicComponent;
use Framework\Core\Database\DB;

class News extends LogicComponent
{
    /** @var DB */
    private $db = null;

    public function init()
    {
        $this->db = $this->dbFactory->GetDbInstance(DB_EXAMPLE);
    }

    public function getAllNews($limit = 10)
    {
        $query = "SELECT * FROM news LIMIT 0, $limit";

        return $this->db->ExecuteTableQuery($query);
    }
}

