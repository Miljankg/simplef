<?php

$lang['test_page'] = "testing";