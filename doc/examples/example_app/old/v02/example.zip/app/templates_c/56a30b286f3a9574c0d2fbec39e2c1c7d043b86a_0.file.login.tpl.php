<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:44
         compiled from "/var/www/html/example/src/app/templates/out_components/login/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:126282561157101b40ad3428_65612086%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '56a30b286f3a9574c0d2fbec39e2c1c7d043b86a' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/login/login.tpl',
      1 => 1460670505,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '126282561157101b40ad3428_65612086',
  'variables' => 
  array (
    'username' => 0,
    'refererPage' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b40afd113_46573756',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b40afd113_46573756')) {
function content_57101b40afd113_46573756 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '126282561157101b40ad3428_65612086';
?>
<form name="login_form" method="post" action="">
    <input type="text" placeholder="Username" name="username" value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
"/><br/><br/>
    <input type="password" placeholder="Password" name="password"/><br/><br/>
    <input type="submit" value="Login" name="login_form_submit"/>
	<input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['refererPage']->value;?>
" name="referer_page"/>
</form>
<?php if (isset($_smarty_tpl->tpl_vars['message']->value)) {?>
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

<?php }
}
}
?>