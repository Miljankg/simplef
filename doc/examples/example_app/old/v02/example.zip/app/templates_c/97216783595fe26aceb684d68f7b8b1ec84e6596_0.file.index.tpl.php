<?php /* Smarty version 3.1.27, created on 2016-04-15 00:42:32
         compiled from "/var/www/html/example/src/app/templates/index/index.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:124474484557101cd8606025_80693362%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97216783595fe26aceb684d68f7b8b1ec84e6596' => 
    array (
      0 => '/var/www/html/example/src/app/templates/index/index.tpl',
      1 => 1460673748,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '124474484557101cd8606025_80693362',
  'variables' => 
  array (
    'header' => 0,
    'oc_menu' => 0,
    'mainContent' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101cd860add9_70326809',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101cd860add9_70326809')) {
function content_57101cd860add9_70326809 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '124474484557101cd8606025_80693362';
?>
<!DOCTYPE HTML>
<html>

<head>
    <title>SF Example</title>
    <meta name="description" content="SF Test example" />
    <meta name="keywords" content="simple framework, test, example" />
    <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
    <?php echo $_smarty_tpl->tpl_vars['header']->value;?>

</head>

<body>
<div id="main">
    <div id="header">
    <div id="logo">
        <div id="logo_text">
            <!-- class="logo_colour", allows you to change the colour of the text -->
            <h1><a href="index.html">simple<span class="logo_colour">style_1</span></a></h1>
            <h2>Simple. Contemporary. Website Template.</h2>
        </div>
    </div>
    <div id="menubar">
        <?php echo $_smarty_tpl->tpl_vars['oc_menu']->value;?>

    </div>
</div>

    <div id="content_header"></div>
    <div id="site_content">
        <div class="sidebar">

        </div>
        <div id="content">
            <?php echo $_smarty_tpl->tpl_vars['mainContent']->value;?>

        </div>
    </div>
    <div id="content_footer"></div>
    <div id="footer">
        Copyright &copy; simplestyle_1 | <a href="http://validator.w3.org/check?uri=referer">HTML5</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> | <a href="http://www.html5webtemplates.co.uk">Website templates</a>
    </div>
</div>
</body>
</html>
<?php }
}
?>