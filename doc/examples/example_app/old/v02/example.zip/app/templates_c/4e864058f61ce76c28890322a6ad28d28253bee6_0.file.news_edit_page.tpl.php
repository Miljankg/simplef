<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:51
         compiled from "/var/www/html/example/src/app/templates/pages/news_edit_page/news_edit_page.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18586682057101b47409274_70407789%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4e864058f61ce76c28890322a6ad28d28253bee6' => 
    array (
      0 => '/var/www/html/example/src/app/templates/pages/news_edit_page/news_edit_page.tpl',
      1 => 1460673138,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18586682057101b47409274_70407789',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b47409d86_91442544',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b47409d86_91442544')) {
function content_57101b47409d86_91442544 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '18586682057101b47409274_70407789';
?>
This is page "news_edit_page". Hello!<?php }
}
?>