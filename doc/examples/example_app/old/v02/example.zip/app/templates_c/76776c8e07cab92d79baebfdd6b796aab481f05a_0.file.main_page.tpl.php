<?php /* Smarty version 3.1.27, created on 2016-04-15 00:51:24
         compiled from "/var/www/html/example/src/app/templates/pages/main_page/main_page.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:192669692457101eeca42e99_87827865%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '76776c8e07cab92d79baebfdd6b796aab481f05a' => 
    array (
      0 => '/var/www/html/example/src/app/templates/pages/main_page/main_page.tpl',
      1 => 1460673708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '192669692457101eeca42e99_87827865',
  'variables' => 
  array (
    'oc_latest_news_main' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101eeca44036_62162758',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101eeca44036_62162758')) {
function content_57101eeca44036_62162758 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '192669692457101eeca42e99_87827865';
echo $_smarty_tpl->tpl_vars['oc_latest_news_main']->value;?>

<?php }
}
?>