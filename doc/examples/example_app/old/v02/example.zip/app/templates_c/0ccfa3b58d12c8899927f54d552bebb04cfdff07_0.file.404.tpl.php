<?php /* Smarty version 3.1.27, created on 2016-04-14 23:49:43
         compiled from "/var/www/html/example/src/app/templates/pages/404/404.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14185916957101077ce79a3_19050848%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0ccfa3b58d12c8899927f54d552bebb04cfdff07' => 
    array (
      0 => '/var/www/html/example/src/app/templates/pages/404/404.tpl',
      1 => 1460670505,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14185916957101077ce79a3_19050848',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101077d0f402_50186073',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101077d0f402_50186073')) {
function content_57101077d0f402_50186073 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '14185916957101077ce79a3_19050848';
?>
PAGE NOT FOUND
<?php }
}
?>