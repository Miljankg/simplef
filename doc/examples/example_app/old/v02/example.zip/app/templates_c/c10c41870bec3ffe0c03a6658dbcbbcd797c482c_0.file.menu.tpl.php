<?php /* Smarty version 3.1.27, created on 2016-04-15 00:42:32
         compiled from "/var/www/html/example/src/app/templates/out_components/menu/menu.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:188834524057101cd85b0954_43311960%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c10c41870bec3ffe0c03a6658dbcbbcd797c482c' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/menu/menu.tpl',
      1 => 1460673600,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '188834524057101cd85b0954_43311960',
  'variables' => 
  array (
    'menuItems' => 0,
    'menuItem' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101cd85e47e1_27249286',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101cd85e47e1_27249286')) {
function content_57101cd85e47e1_27249286 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '188834524057101cd85b0954_43311960';
?>
<ul id="menu">
    <?php
$_from = $_smarty_tpl->tpl_vars['menuItems']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['menuItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['menuItem']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['menuItem']->value) {
$_smarty_tpl->tpl_vars['menuItem']->_loop = true;
$foreach_menuItem_Sav = $_smarty_tpl->tpl_vars['menuItem'];
?>
    <li class="<?php echo $_smarty_tpl->tpl_vars['menuItem']->value['selected'];?>
"><a href="<?php echo $_smarty_tpl->tpl_vars['menuItem']->value['page_url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuItem']->value['page_translate'];?>
</a></li>
    <?php
$_smarty_tpl->tpl_vars['menuItem'] = $foreach_menuItem_Sav;
}
?>
</ul>

<?php }
}
?>