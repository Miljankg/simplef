<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:44
         compiled from "/var/www/html/example/src/app/templates/pages/login/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:134021525857101b40aff3c1_03396950%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31e00e913a309537b8c31eca9dce0d3794c920a2' => 
    array (
      0 => '/var/www/html/example/src/app/templates/pages/login/login.tpl',
      1 => 1460670505,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '134021525857101b40aff3c1_03396950',
  'variables' => 
  array (
    'oc_login' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b40b051f8_16351367',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b40b051f8_16351367')) {
function content_57101b40b051f8_16351367 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '134021525857101b40aff3c1_03396950';
echo $_smarty_tpl->tpl_vars['oc_login']->value;

}
}
?>