<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:51
         compiled from "/var/www/html/example/src/app/templates/out_components/add_news/add_news.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:71054176557101b473ea398_71219703%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '302ba511058f951a70e8de42836d3b89a7476ec7' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/add_news/add_news.tpl',
      1 => 1460673011,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '71054176557101b473ea398_71219703',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b47402ef1_11390650',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b47402ef1_11390650')) {
function content_57101b47402ef1_11390650 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '71054176557101b473ea398_71219703';
?>
This is component "add_news". Hello!<?php }
}
?>