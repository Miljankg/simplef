<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:51
         compiled from "/var/www/html/example/src/app/templates/out_components/edit_delete_news/edit_delete_news.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:203873613857101b47406f52_08831412%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5068d0f90eb068d3a63ce07cfc6c8b03d0ed395f' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/edit_delete_news/edit_delete_news.tpl',
      1 => 1460673022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203873613857101b47406f52_08831412',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b47407c26_40042775',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b47407c26_40042775')) {
function content_57101b47407c26_40042775 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '203873613857101b47406f52_08831412';
?>
This is component "edit_delete_news". Hello!<?php }
}
?>