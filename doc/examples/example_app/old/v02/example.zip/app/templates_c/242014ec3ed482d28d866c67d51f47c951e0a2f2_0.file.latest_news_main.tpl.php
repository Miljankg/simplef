<?php /* Smarty version 3.1.27, created on 2016-04-15 00:51:24
         compiled from "/var/www/html/example/src/app/templates/out_components/latest_news_main/latest_news_main.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:40506877057101eeca23a17_21620637%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '242014ec3ed482d28d866c67d51f47c951e0a2f2' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/latest_news_main/latest_news_main.tpl',
      1 => 1460673676,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '40506877057101eeca23a17_21620637',
  'variables' => 
  array (
    'news' => 0,
    'article' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101eeca402f3_39057659',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101eeca402f3_39057659')) {
function content_57101eeca402f3_39057659 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '40506877057101eeca23a17_21620637';
$_from = $_smarty_tpl->tpl_vars['news']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['article'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['article']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['article']->value) {
$_smarty_tpl->tpl_vars['article']->_loop = true;
$foreach_article_Sav = $_smarty_tpl->tpl_vars['article'];
?>

    <h2><?php echo $_smarty_tpl->tpl_vars['article']->value['news_title'];?>
</h2><br/>
    <?php echo $_smarty_tpl->tpl_vars['article']->value['news_text'];?>
<br/>
    <?php echo $_smarty_tpl->tpl_vars['article']->value['news_timestamp'];?>
<br/><br/><hr/><br/>

<?php
$_smarty_tpl->tpl_vars['article'] = $foreach_article_Sav;
}
?>

<?php }
}
?>