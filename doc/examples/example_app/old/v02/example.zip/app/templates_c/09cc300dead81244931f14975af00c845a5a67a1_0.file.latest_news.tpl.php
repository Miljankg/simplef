<?php /* Smarty version 3.1.27, created on 2016-04-15 00:35:44
         compiled from "/var/www/html/example/src/app/templates/out_components/latest_news/latest_news.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4989192757101b409ba369_24771073%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '09cc300dead81244931f14975af00c845a5a67a1' => 
    array (
      0 => '/var/www/html/example/src/app/templates/out_components/latest_news/latest_news.tpl',
      1 => 1460673036,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4989192757101b409ba369_24771073',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_57101b40a79869_58463565',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_57101b40a79869_58463565')) {
function content_57101b40a79869_58463565 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '4989192757101b409ba369_24771073';
?>
This is component "latest_news". Hello!<?php }
}
?>