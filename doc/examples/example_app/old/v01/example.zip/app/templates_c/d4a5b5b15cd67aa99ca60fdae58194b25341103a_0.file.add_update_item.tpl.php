<?php /* Smarty version 3.1.27, created on 2016-01-11 05:45:36
         compiled from "C:\xampp\htdocs\test_app\app\templates\pages\add_update_item\add_update_item.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:58185693337086c378_59177191%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd4a5b5b15cd67aa99ca60fdae58194b25341103a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\pages\\add_update_item\\add_update_item.tpl',
      1 => 1452487535,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '58185693337086c378_59177191',
  'variables' => 
  array (
    'item_list' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_569333708b4e19_77237153',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_569333708b4e19_77237153')) {
function content_569333708b4e19_77237153 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '58185693337086c378_59177191';
echo $_smarty_tpl->tpl_vars['item_list']->value;

}
}
?>