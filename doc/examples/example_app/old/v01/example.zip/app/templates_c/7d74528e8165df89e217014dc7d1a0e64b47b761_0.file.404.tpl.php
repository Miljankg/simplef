<?php /* Smarty version 3.1.27, created on 2016-01-11 05:12:16
         compiled from "C:\xampp\htdocs\test_app\app\templates\pages\404\404.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1393956932ba068f8b9_60051926%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7d74528e8165df89e217014dc7d1a0e64b47b761' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\pages\\404\\404.tpl',
      1 => 1452450922,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1393956932ba068f8b9_60051926',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56932ba0826053_19416614',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56932ba0826053_19416614')) {
function content_56932ba0826053_19416614 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1393956932ba068f8b9_60051926';
?>
PAGE NOT FOUND
<?php }
}
?>