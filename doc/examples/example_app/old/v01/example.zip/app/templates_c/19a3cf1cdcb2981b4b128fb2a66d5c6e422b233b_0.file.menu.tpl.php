<?php /* Smarty version 3.1.27, created on 2016-01-11 05:29:28
         compiled from "C:\xampp\htdocs\test_app\app\templates\out_components\menu\menu.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1072556932fa8b09646_19030092%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '19a3cf1cdcb2981b4b128fb2a66d5c6e422b233b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\out_components\\menu\\menu.tpl',
      1 => 1452486445,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1072556932fa8b09646_19030092',
  'variables' => 
  array (
    'menuItems' => 0,
    'menuItem' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56932fa8bc8078_67071294',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56932fa8bc8078_67071294')) {
function content_56932fa8bc8078_67071294 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1072556932fa8b09646_19030092';
?>
<ul>
<?php
$_from = $_smarty_tpl->tpl_vars['menuItems']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['menuItem'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['menuItem']->_loop = false;
$_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['menuItem']->value) {
$_smarty_tpl->tpl_vars['menuItem']->_loop = true;
$foreach_menuItem_Sav = $_smarty_tpl->tpl_vars['menuItem'];
?>
    <li>
        <a href="<?php echo $_smarty_tpl->tpl_vars['menuItem']->value['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuItem']->value['text'];?>
</a>
    </li>
<?php
$_smarty_tpl->tpl_vars['menuItem'] = $foreach_menuItem_Sav;
}
?>
</ul>
<?php }
}
?>