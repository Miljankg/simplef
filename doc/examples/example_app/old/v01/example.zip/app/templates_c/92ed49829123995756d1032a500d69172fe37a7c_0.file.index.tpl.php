<?php /* Smarty version 3.1.27, created on 2016-01-11 05:30:06
         compiled from "C:\xampp\htdocs\test_app\app\templates\index\index.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2384656932fce578498_78042652%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92ed49829123995756d1032a500d69172fe37a7c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\index\\index.tpl',
      1 => 1452486604,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2384656932fce578498_78042652',
  'variables' => 
  array (
    'header' => 0,
    'menu' => 0,
    'mainContent' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_56932fce5e2a39_78857130',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_56932fce5e2a39_78857130')) {
function content_56932fce5e2a39_78857130 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2384656932fce578498_78042652';
?>
<html>
    
    <head>
        <?php echo $_smarty_tpl->tpl_vars['header']->value;?>

    </head>
    
    <body>
        <div class="main-container">
			<?php echo $_smarty_tpl->tpl_vars['menu']->value;?>

            <?php echo $_smarty_tpl->tpl_vars['mainContent']->value;?>

        </div>

    </body>
    
</html>
<?php }
}
?>