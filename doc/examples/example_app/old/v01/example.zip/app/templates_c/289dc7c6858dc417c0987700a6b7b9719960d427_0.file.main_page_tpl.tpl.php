<?php /* Smarty version 3.1.27, created on 2016-01-11 05:58:59
         compiled from "C:\xampp\htdocs\test_app\app\templates\pages\main_page_tpl\main_page_tpl.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:26716569336932e1f30_63715707%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '289dc7c6858dc417c0987700a6b7b9719960d427' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\pages\\main_page_tpl\\main_page_tpl.tpl',
      1 => 1452488233,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '26716569336932e1f30_63715707',
  'variables' => 
  array (
    'add_item' => 0,
    'item_list' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_569336932e9ad7_65214358',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_569336932e9ad7_65214358')) {
function content_569336932e9ad7_65214358 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '26716569336932e1f30_63715707';
?>
<div id="main-container">
    <div id="main-column" class="column">
        <?php if (isset($_smarty_tpl->tpl_vars['add_item']->value)) {
echo $_smarty_tpl->tpl_vars['add_item']->value;
}?>
    </div>
    <div id="secondary-column" class="column">
        <?php echo $_smarty_tpl->tpl_vars['item_list']->value;?>

    </div>
</div>
<?php }
}
?>