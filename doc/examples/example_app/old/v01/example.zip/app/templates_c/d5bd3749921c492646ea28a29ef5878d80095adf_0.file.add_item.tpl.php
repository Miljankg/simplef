<?php /* Smarty version 3.1.27, created on 2016-01-11 05:58:58
         compiled from "C:\xampp\htdocs\test_app\app\templates\out_components\add_item\add_item.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1812756933692e10f40_49972025%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd5bd3749921c492646ea28a29ef5878d80095adf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\out_components\\add_item\\add_item.tpl',
      1 => 1452488247,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1812756933692e10f40_49972025',
  'variables' => 
  array (
    'addItemMessage' => 0,
    'formActionUrl' => 0,
    'itemName' => 0,
    'itemCount' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_569336931a1a53_31521246',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_569336931a1a53_31521246')) {
function content_569336931a1a53_31521246 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1812756933692e10f40_49972025';
if (!empty($_smarty_tpl->tpl_vars['addItemMessage']->value)) {?>
    <div id="add-item-message">
        <?php echo $_smarty_tpl->tpl_vars['addItemMessage']->value;?>

    </div>
<?php }?>
<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['formActionUrl']->value;?>
">
    <label>Item name</label><input type="text" name="item_name" value="<?php echo $_smarty_tpl->tpl_vars['itemName']->value;?>
"/><br/>
    <label>Item count</label><input type="text" name="item_count" value="<?php echo $_smarty_tpl->tpl_vars['itemCount']->value;?>
"/><br/>
    <input type="submit" name="add_item_to_db" value="Add item"/><br/>
</form>
<?php }
}
?>