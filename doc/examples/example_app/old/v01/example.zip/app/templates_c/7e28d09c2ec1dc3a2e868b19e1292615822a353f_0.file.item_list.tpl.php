<?php /* Smarty version 3.1.27, created on 2016-01-11 05:42:35
         compiled from "C:\xampp\htdocs\test_app\app\templates\out_components\item_list\item_list.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:6958569332bbbb7323_16767171%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7e28d09c2ec1dc3a2e868b19e1292615822a353f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\test_app\\app\\templates\\out_components\\item_list\\item_list.tpl',
      1 => 1452487189,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6958569332bbbb7323_16767171',
  'variables' => 
  array (
    'listItems' => 0,
    'langOutComp' => 0,
    'item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_569332bbcc1160_12788960',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_569332bbcc1160_12788960')) {
function content_569332bbcc1160_12788960 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '6958569332bbbb7323_16767171';
if (empty($_smarty_tpl->tpl_vars['listItems']->value)) {?>
    <?php echo $_smarty_tpl->tpl_vars['langOutComp']->value->get("no_items");?>

<?php } else { ?>
    <table border="1">
    <tr>
        <th>
            <?php echo $_smarty_tpl->tpl_vars['langOutComp']->value->get("item_id");?>

        </th>
        <th>
            <?php echo $_smarty_tpl->tpl_vars['langOutComp']->value->get("item_name");?>

        </th>
        <th>
            <?php echo $_smarty_tpl->tpl_vars['langOutComp']->value->get("item_count");?>

        </th>
    </tr>
    <?php
$_from = $_smarty_tpl->tpl_vars['listItems']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['item'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['item']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->_loop = true;
$foreach_item_Sav = $_smarty_tpl->tpl_vars['item'];
?>
        <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['item']->value['item_id'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['item']->value['item_name'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['item']->value['item_count'];?>
</td>
        </tr>
    <?php
$_smarty_tpl->tpl_vars['item'] = $foreach_item_Sav;
}
?>
    </table>
<?php }

}
}
?>