<?php

namespace Components\Output;

use Core\Components\OutputComponent;
use Core\SF;

class ItemList extends OutputComponent {
	
    protected function execute() {
		
        $itemOperations = $this->getLogicComponent(LOGIC_ITEM_OPERATIONS);
		
        $items = $itemOperations->getAllItems();
		
        $this->tplEngine->assign("listItems", $items);
		
    }
}
