<?php
namespace Components\Logic;

use Core\Components\LogicComponent;
use Core\Database\QueryTypes;

class ItemOperations extends LogicComponent {
	
    public function init() {
        // nothing to  nitialize
    }
	
    public function getAllItems() {
		
        return $this->db->ExecuteDirectQuery(
            "SELECT * FROM items",
            QueryTypes::TABLE,
            EXAMPLE_DB
        );
		
    }
	
	public function addItem($itemName, $itemCount) {
		
        $query = "INSERT INTO items (item_name, item_count) VALUES(\"$itemName\", \"$itemCount\")";
		
        $this->db->ExecuteDirectQuery($query, QueryTypes::NON_SELECT, EXAMPLE_DB);
	}

}
