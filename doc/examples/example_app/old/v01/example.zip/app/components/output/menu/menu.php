<?php

namespace Components\Output;

use Core\Components\OutputComponent;
use Core\SF;

class Menu extends OutputComponent {

    protected function execute()
    {
        $menuItems = $this->config->get("menu_items");

        $menu = array();

        foreach ($menuItems as $menuItem) {

            $translation = $this->langObj->get("lang_" . $menuItem);

            $url = SF::$config->get("main_url") . $menuItem;

            $menu[$menuItem]["url"] = $url;
            $menu[$menuItem]["text"] = $translation;

                }

        $this->tplEngine->assign("menuItems", $menu);
    }

}
