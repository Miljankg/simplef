<?php

$lang["lang_" . PAGE_ADD_UPDATE_ITEM] = "ADD / UPDATE";
$lang["lang_" . PAGE_DELETE_ITEM] = "DELETE";
