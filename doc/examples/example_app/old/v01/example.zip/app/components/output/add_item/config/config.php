<?php

$config["menu_items"] = array(
    PAGE_ADD_UPDATE_ITEM,
    PAGE_DELETE_ITEM
);
