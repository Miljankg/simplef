<?php

$lang["item_id"]    = "Item id";
$lang["item_name"]  = "Item name";
$lang["item_count"] = "Item count";
$lang["no_items"]   = "Currently, there is no items";
