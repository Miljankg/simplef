<?php

$lang['add_item']   = 'Add item';
$lang['item_name']  = 'Item name';
$lang['item_count'] = 'Item count';
$lang['empty_name'] = 'Name cannot be empty.';
$lang['must_be_number'] = 'Item count must be a number.';
