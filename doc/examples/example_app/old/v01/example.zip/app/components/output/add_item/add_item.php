<?php
namespace Components\Output;

use Core\Components\OutputComponent;
use Core\URLUtils\URL;
use Core\SF;

class AddItem extends OutputComponent {
	
    public function execute() {
		
        $formSubmitted = false;
        $itemName = "";
        $itemCount = "";
        $currentPage = SF::$config->get('main_url') . SF::$config->get('current_page');
		
        if (isset($_POST['add_item_to_db'])) {
            $formSubmitted = true;
        }
		
        $message = "";
		
        if ($formSubmitted) {			
            if ($this->addItem($message, $itemName, $itemCount))
                URL::redirect($currentPage);
        }
		
        $formActionUrl = $currentPage;
        $this->tplEngine->assign('formActionUrl', $formActionUrl);
        $this->tplEngine->assign('addItemMessage', $message);
        $this->tplEngine->assign('itemName', $itemName);
        $this->tplEngine->assign('itemCount', $itemCount);
		
    }
	
    private function addItem(&$message, &$itemName, &$itemCount) {
        $itemName = $_POST['item_name'];
        $itemCount = $_POST['item_count'];
        if (empty($itemName)) {
            $message = $this->langObj->get('empty_name');
            return false;
        }
        if (!is_numeric($itemCount)) {
            $message = $this->langObj->get('must_be_number');
            return false;
        }
        $logicItemOperations = $this->getLogicComponent(LOGIC_ITEM_OPERATIONS);
        $logicItemOperations->addItem($itemName, $itemCount);

        return true;
    }
}
