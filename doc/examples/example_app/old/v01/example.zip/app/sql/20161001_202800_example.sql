CREATE DATABASE example_db;

USE example_db;

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL COMMENT 'ID of the item',
  `item_name` varchar(255) NOT NULL,
  `item_count` int(11) NOT NULL DEFAULT '0',
  `item_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `user_name`, `user_pass`) VALUES
(1, 'testuser1', '098f6bcd4621d373cade4e832627b4f6'),
(2, 'testuser2', '098f6bcd4621d373cade4e832627b4f6');

ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID of the item';
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
