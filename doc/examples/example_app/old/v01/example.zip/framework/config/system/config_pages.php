<?php

/* Output components */
define("OUTCOMP_MENU", "menu");
define("OUTCOMP_ITEM_LIST", "item_list");
define("OUTCOMP_ADD_ITEM", "add_item");

define("LOGIC_ITEM_OPERATIONS", "item_operations");

$config['output_components'] = array(
    
                OUTCOMP_MENU => array(),
				OUTCOMP_ITEM_LIST => array(),
				OUTCOMP_ADD_ITEM => array()
    
            );

$config['output_components_logic'] = array(
    OUTCOMP_ITEM_LIST => array(LOGIC_ITEM_OPERATIONS),
	OUTCOMP_ADD_ITEM => array(LOGIC_ITEM_OPERATIONS)
);

/* Pages */
define("PAGE_404", "404");
define("PAGE_ADD_UPDATE_ITEM", "add_update_item");
define("PAGE_DELETE_ITEM", "delete_item");
define("PAGE_LOGIN", "login");



$config['pages'] =
        array(
            PAGE_404,
			PAGE_ADD_UPDATE_ITEM,
			PAGE_DELETE_ITEM,
			PAGE_LOGIN
        );
        
        
$config['pages_out_components'] = 
        array(
            PAGE_404 => array(
                
            ),
			PAGE_ADD_UPDATE_ITEM => array(OUTCOMP_ITEM_LIST, OUTCOMP_ADD_ITEM),
			PAGE_DELETE_ITEM => array(OUTCOMP_ITEM_LIST),
			PAGE_LOGIN => array()
        ); 

$config['pages_templates'] =
        array(
            PAGE_ADD_UPDATE_ITEM => "main_page_tpl",
            PAGE_DELETE_ITEM => "main_page_tpl"
        );

/* Pages */
$config['default_page']         = ""; // Empty = root
$config['empty_page_index']     = PAGE_ADD_UPDATE_ITEM;
$config['page_not_found_page']  = PAGE_404;
$config['wrap_components']      = true;
$config['common_output_components'] = array(
	OUTCOMP_MENU => array(PAGE_LOGIN)
);