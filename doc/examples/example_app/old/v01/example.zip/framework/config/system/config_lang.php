<?php

$config['is_site_multilang']    = true;

/* Languages */
$config['default_language']     = 'en';
$config['available_langs']      = array('en');
$config['lang_dir']             = $config['app_dir'] . 'lang' . $config['ds'];


