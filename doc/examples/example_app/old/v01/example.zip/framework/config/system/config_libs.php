<?php

/**
 * Loads library by including DOCUMENT_ROOT . libs . LIB_NAME . incl_lib.php
 */

$config['sf_libs'] =  array(
    'smarty'
);