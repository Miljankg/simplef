<?php

define('EXAMPLE_DB', 'example_db');

$config['db_config'] = array(
    EXAMPLE_DB => array(
       	'db_type' => 'mysql', 
		'db_user' => 'some_user',
		'db_pass' => 'some_pass',
		'db_host' => 'localhost', 
		'db_name' => 'example_db'
    )

);   // type of DB => [ Currently supported: "mysql", "oracle" ] 

