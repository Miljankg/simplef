<?php

$config['ssl_port'] = 443;

$config['out_comp_ns'] = 'Components\\Output\\';
$config['logic_comp_ns'] = 'Components\\Logic\\';

/* CLI */
$config['is_cli'] = ""; // Generated from SF Core if set as empty string.