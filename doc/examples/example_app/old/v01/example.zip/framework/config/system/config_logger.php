<?php

$config['error_log_enabled']    = true;

$config['log_file']             = $config['framework_dir'] . "log" . $config['ds'] . "sf.log";
$config['log_time_format']      = '[ Y-m-d H:i:s ]'; 
$config['new_line']             = PHP_EOL;
