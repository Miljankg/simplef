<?php /* Smarty version 3.1.27, created on 2016-06-22 14:59:58
         compiled from "C:\xampp\htdocs\s\src\app\templates\out_components\login\login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:7160576a8bce541f16_11633215%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dcace734613adf0b776c9529a97c27cd31e29928' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\out_components\\login\\login.tpl',
      1 => 1466599814,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7160576a8bce541f16_11633215',
  'variables' => 
  array (
    'username' => 0,
    'refererPage' => 0,
    'message' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a8bce5845b0_32411728',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a8bce5845b0_32411728')) {
function content_576a8bce5845b0_32411728 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '7160576a8bce541f16_11633215';
?>
<form name="login_form" method="post" action="">
    <input type="text" placeholder="Username" name="username" value="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
"/><br/><br/>
    <input type="password" placeholder="Password" name="password"/><br/><br/>
    <input type="submit" value="Login" name="login_form_submit"/>
	<input type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['refererPage']->value;?>
" name="referer_page"/>
</form>
<?php if (isset($_smarty_tpl->tpl_vars['message']->value)) {?>
    <?php echo $_smarty_tpl->tpl_vars['message']->value;?>

<?php }
}
}
?>