<?php /* Smarty version 3.1.27, created on 2016-06-22 15:00:02
         compiled from "C:\xampp\htdocs\s\src\app\templates\out_components\add_news\add_news.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14276576a8bd2ae1260_61162088%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd70d9de00f51a04d601a7f0193431bd55b8bfcfe' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\out_components\\add_news\\add_news.tpl',
      1 => 1466600093,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14276576a8bd2ae1260_61162088',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a8bd2b1bbf9_13959237',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a8bd2b1bbf9_13959237')) {
function content_576a8bd2b1bbf9_13959237 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '14276576a8bd2ae1260_61162088';
?>
This is component "add_news". Hello!<?php }
}
?>