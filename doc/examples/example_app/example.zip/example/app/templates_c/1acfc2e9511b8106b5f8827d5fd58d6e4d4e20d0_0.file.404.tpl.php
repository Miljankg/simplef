<?php /* Smarty version 3.1.27, created on 2016-06-22 14:51:26
         compiled from "C:\xampp\htdocs\s\src\app\templates\pages\404\404.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:29270576a89ce5aaa97_77342749%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1acfc2e9511b8106b5f8827d5fd58d6e4d4e20d0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\pages\\404\\404.tpl',
      1 => 1466599814,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29270576a89ce5aaa97_77342749',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a89ce5d98a9_39633038',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a89ce5d98a9_39633038')) {
function content_576a89ce5d98a9_39633038 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '29270576a89ce5aaa97_77342749';
?>
PAGE NOT FOUND
<?php }
}
?>