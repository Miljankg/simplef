<?php /* Smarty version 3.1.27, created on 2016-06-22 15:06:37
         compiled from "C:\xampp\htdocs\s\src\app\templates\out_components\latest_news\latest_news.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:29255576a8d5df1d393_15138296%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a83eb9acff842db0b13d81f5d64eacbe088a544f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\out_components\\latest_news\\latest_news.tpl',
      1 => 1466600742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29255576a8d5df1d393_15138296',
  'variables' => 
  array (
    'news' => 0,
    'article' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a8d5e01d639_74749029',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a8d5e01d639_74749029')) {
function content_576a8d5e01d639_74749029 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '29255576a8d5df1d393_15138296';
$_from = $_smarty_tpl->tpl_vars['news']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['article'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['article']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['article']->value) {
$_smarty_tpl->tpl_vars['article']->_loop = true;
$foreach_article_Sav = $_smarty_tpl->tpl_vars['article'];
?>
<h2><?php echo $_smarty_tpl->tpl_vars['article']->value['news_title'];?>
</h2><br/>
<?php echo $_smarty_tpl->tpl_vars['article']->value['news_text'];?>
<br/>
<?php echo $_smarty_tpl->tpl_vars['article']->value['news_timestamp'];?>
<br/><br/><hr/><br/>
<?php
$_smarty_tpl->tpl_vars['article'] = $foreach_article_Sav;
}
}
}
?>