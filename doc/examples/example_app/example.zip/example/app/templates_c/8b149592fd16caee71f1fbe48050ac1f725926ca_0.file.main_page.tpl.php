<?php /* Smarty version 3.1.27, created on 2016-06-22 15:06:38
         compiled from "C:\xampp\htdocs\s\src\app\templates\pages\main_page\main_page.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:31348576a8d5e0408c1_22022412%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8b149592fd16caee71f1fbe48050ac1f725926ca' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\pages\\main_page\\main_page.tpl',
      1 => 1466600761,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31348576a8d5e0408c1_22022412',
  'variables' => 
  array (
    'oc_latest_news' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a8d5e044746_59372590',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a8d5e044746_59372590')) {
function content_576a8d5e044746_59372590 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '31348576a8d5e0408c1_22022412';
echo $_smarty_tpl->tpl_vars['oc_latest_news']->value;

}
}
?>