<?php /* Smarty version 3.1.27, created on 2016-06-22 15:00:02
         compiled from "C:\xampp\htdocs\s\src\app\templates\pages\news_edit_page\news_edit_page.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9901576a8bd2b33308_41949800%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ecfaa26003f7ead5961d1921b4ef0539958d34be' => 
    array (
      0 => 'C:\\xampp\\htdocs\\s\\src\\app\\templates\\pages\\news_edit_page\\news_edit_page.tpl',
      1 => 1466600254,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9901576a8bd2b33308_41949800',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_576a8bd2b33300_43641288',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_576a8bd2b33300_43641288')) {
function content_576a8bd2b33300_43641288 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '9901576a8bd2b33308_41949800';
?>
This is page "news_edit_page". Hello!<?php }
}
?>