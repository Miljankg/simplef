<?php

$lang['main_page'] = "glavna";