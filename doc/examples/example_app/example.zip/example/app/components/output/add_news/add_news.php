<?php

namespace Components\Output;

use Framework\Core\FrameworkClasses\Components\OutputComponent;

class AddNews extends OutputComponent
{
    protected function execute()
    {
    }
}