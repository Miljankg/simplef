<?php

$lang['bad_credentials'] = 'Bad credentials, please try again.';