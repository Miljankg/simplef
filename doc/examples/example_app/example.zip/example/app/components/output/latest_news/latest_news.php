<?php
namespace Components\Output;
use Framework\Core\FrameworkClasses\Components\OutputComponent;
use Components\Logic\News;
class LatestNews extends OutputComponent
{
protected function execute()
{
/** @var $lcNews News */
$lcNews = $this->getLogicComponent(LC_NEWS);
$news = $lcNews->getAllNews($this->config->get('latest_news_count'));
$this->tplEngine->assign('news', $news);
}
}