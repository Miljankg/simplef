<?php
namespace Components\Output;
use Framework\Core\FrameworkClasses\Components\OutputComponent;
class Menu extends OutputComponent
{
protected function execute()
{
$skipPages = array('error_page', 'maintenance', 'login', '404');
$pages = $this->sf->Config()->get('pages');
$mainUrl = $this->sf->Config()->get('main_url');
$currentPage = $this->sf->Url()->getCurrentPageName();
$menu = array();
foreach ($pages as $pageName => $pageConfig)
{
if (in_array($pageName, $skipPages))
continue;
$translation = "";
try
{
$translation = $this->sf->LangPages()->get('page_' . $pageName);
}
catch (\Exception $ex)
{
$translation = $pageName;
}
$menuItem = array();
$menuItem['page_translate'] = $translation;
$menuItem['page_url'] = $mainUrl . $pageName;
$menuItem['selected'] = ($currentPage == $pageName) ? 'selected' : '';
$menu[] = $menuItem;
}
$this->tplEngine->assign('menuItems', $menu);
}
}