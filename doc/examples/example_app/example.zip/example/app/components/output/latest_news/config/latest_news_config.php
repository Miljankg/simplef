<?php
$config['latest_news_count'] = 10;