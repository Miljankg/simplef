<?php

$config['db_config']                     = array (
  'example' => 
  array (
    'db_type' => 'mysql',
    'db_user' => 'root',
    'db_pass' => '',
    'db_host' => 'localhost',
    'db_name' => 'example',
  ),
);
