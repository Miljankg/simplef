<?php

$config['sf_libs']                       = array (
  0 => 'smarty',
);
