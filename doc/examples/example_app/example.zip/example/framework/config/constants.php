<?php

define('LOG_LEVEL_ALL', 'ALL');
define('ROLE_LOGGED_IN', 'logged_in');
define('LOGIC_AUTH', 'auth');
define('OC_LOGIN', 'login');
define('PAGE_404', '404');
define('PAGE_MAINTENANCE', 'maintenance');
define('PAGE_ERROR', 'error_page');
define('PAGE_TEST', 'test_page');
define('PAGE_LOGIN', 'login');
define('DB_EXAMPLE', 'example');
define('LC_NEWS', 'news');
define('OC_LATEST_NEWS', 'latest_news');
define('OC_ADD_NEWS', 'add_news');
define('OC_MENU', 'menu');
define('PAGE_MAIN_PAGE', 'main_page');
define('PAGE_NEWS_EDIT_PAGE', 'news_edit_page');
