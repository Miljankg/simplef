<?php

$config['ssl_port']                      = 443;
$config['out_comp_ns']                   = 'Components\\Output\\';
$config['logic_comp_ns']                 = 'Components\\Logic\\';
$config['is_cli']                        = '';
$config['ajax_get_index']                = 'ajax';
$config['ajax_level']                    = '1';
$config['enable_session']                = true;
$config['maintenance_mode']              = false;
