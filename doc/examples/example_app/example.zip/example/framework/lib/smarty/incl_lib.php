<?php

require_once 'libs/Smarty.class.php';

